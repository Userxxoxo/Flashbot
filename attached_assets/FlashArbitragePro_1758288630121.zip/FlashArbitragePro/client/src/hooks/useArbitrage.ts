import { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { apiRequest } from '@/lib/queryClient';
import { useToast } from '@/hooks/use-toast';

export function useArbitrage() {
  const [isLoading, setIsLoading] = useState(false);
  const { toast } = useToast();
  const queryClient = useQueryClient();

  // Query for engine status
  const { data: engineStatus } = useQuery({
    queryKey: ['/api/engine/status'],
    refetchInterval: 5000,
  });

  // Query for opportunities
  const { data: opportunities } = useQuery({
    queryKey: ['/api/opportunities'],
    refetchInterval: 10000,
  });

  // Query for statistics
  const { data: stats } = useQuery({
    queryKey: ['/api/stats'],
    refetchInterval: 15000,
  });

  // Query for DEX protocols
  const { data: protocols } = useQuery({
    queryKey: ['/api/dex/protocols'],
    refetchInterval: 30000,
  });

  // Start engine mutation
  const startEngineMutation = useMutation({
    mutationFn: () => apiRequest('POST', '/api/engine/start'),
    onSuccess: () => {
      toast({
        title: "Engine Started",
        description: "Arbitrage scanning has begun",
      });
      queryClient.invalidateQueries({ queryKey: ['/api/engine/status'] });
    },
    onError: (error: any) => {
      toast({
        title: "Failed to Start Engine",
        description: error.message || "An error occurred",
        variant: "destructive",
      });
    }
  });

  // Stop engine mutation
  const stopEngineMutation = useMutation({
    mutationFn: () => apiRequest('POST', '/api/engine/stop'),
    onSuccess: () => {
      toast({
        title: "Engine Stopped",
        description: "Arbitrage scanning has stopped",
      });
      queryClient.invalidateQueries({ queryKey: ['/api/engine/status'] });
    },
    onError: (error: any) => {
      toast({
        title: "Failed to Stop Engine",
        description: error.message || "An error occurred",
        variant: "destructive",
      });
    }
  });

  // Deploy contract mutation
  const deployContractMutation = useMutation({
    mutationFn: () => apiRequest('POST', '/api/contract/deploy'),
    onSuccess: (response: any) => {
      toast({
        title: "Contract Deployed",
        description: `Contract deployed at ${response.contractAddress}`,
      });
      queryClient.invalidateQueries({ queryKey: ['/api/engine/status'] });
    },
    onError: (error: any) => {
      toast({
        title: "Failed to Deploy Contract",
        description: error.message || "An error occurred",
        variant: "destructive",
      });
    }
  });

  // Withdraw from contract mutation
  const withdrawMutation = useMutation({
    mutationFn: (tokenAddress?: string) => 
      apiRequest('POST', '/api/contract/withdraw', { tokenAddress }),
    onSuccess: () => {
      toast({
        title: "Withdrawal Successful",
        description: "Funds have been withdrawn from the contract",
      });
      queryClient.invalidateQueries({ queryKey: ['/api/stats'] });
    },
    onError: (error: any) => {
      toast({
        title: "Withdrawal Failed",
        description: error.message || "An error occurred",
        variant: "destructive",
      });
    }
  });

  // Execute arbitrage mutation
  const executeArbitrageMutation = useMutation({
    mutationFn: (opportunityId: string) => 
      apiRequest('POST', `/api/opportunities/${opportunityId}/execute`),
    onSuccess: () => {
      toast({
        title: "Arbitrage Executed",
        description: "Trade has been submitted to the blockchain",
      });
      queryClient.invalidateQueries({ queryKey: ['/api/opportunities'] });
      queryClient.invalidateQueries({ queryKey: ['/api/stats'] });
    },
    onError: (error: any) => {
      toast({
        title: "Execution Failed",
        description: error.message || "An error occurred",
        variant: "destructive",
      });
    }
  });

  // Wrapper functions
  const startEngine = async () => {
    setIsLoading(true);
    try {
      await startEngineMutation.mutateAsync();
    } finally {
      setIsLoading(false);
    }
  };

  const stopEngine = async () => {
    setIsLoading(true);
    try {
      await stopEngineMutation.mutateAsync();
    } finally {
      setIsLoading(false);
    }
  };

  const deployContract = async () => {
    setIsLoading(true);
    try {
      await deployContractMutation.mutateAsync();
    } finally {
      setIsLoading(false);
    }
  };

  const withdrawFromContract = async (tokenAddress?: string) => {
    setIsLoading(true);
    try {
      await withdrawMutation.mutateAsync(tokenAddress);
    } finally {
      setIsLoading(false);
    }
  };

  const executeArbitrage = async (opportunityId: string) => {
    setIsLoading(true);
    try {
      await executeArbitrageMutation.mutateAsync(opportunityId);
    } finally {
      setIsLoading(false);
    }
  };

  return {
    engineStatus,
    opportunities,
    stats,
    protocols,
    startEngine,
    stopEngine,
    deployContract,
    withdrawFromContract,
    executeArbitrage,
    isLoading: isLoading || 
      startEngineMutation.isPending || 
      stopEngineMutation.isPending || 
      deployContractMutation.isPending || 
      withdrawMutation.isPending ||
      executeArbitrageMutation.isPending
  };
}

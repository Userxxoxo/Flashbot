import { useState, useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import { useWebSocket } from "@/hooks/useWebSocket";
import { useArbitrage } from "@/hooks/useArbitrage";
import StatusCard from "@/components/StatusCard";
import MetricCard from "@/components/MetricCard";
import EngineControls from "@/components/EngineControls";
import OpportunitiesTab from "@/components/OpportunitiesTab";
import DexProtocolsTab from "@/components/DexProtocolsTab";
import { Activity, FileText, Wallet, DollarSign, Globe, Clock, BarChart3 } from "lucide-react";

export default function Dashboard() {
  const [activeTab, setActiveTab] = useState<'opportunities' | 'protocols'>('opportunities');
  
  // WebSocket connection for real-time updates
  const { isConnected, lastMessage } = useWebSocket();
  
  // Custom hooks for arbitrage data
  const { 
    engineStatus, 
    opportunities, 
    stats, 
    protocols,
    startEngine,
    stopEngine,
    deployContract,
    withdrawFromContract,
    isLoading 
  } = useArbitrage();

  // Fetch initial data
  const { data: engineData = {} } = useQuery({
    queryKey: ['/api/engine/status'],
    refetchInterval: 5000, // Refresh every 5 seconds
  });

  const { data: statsData = {} } = useQuery({
    queryKey: ['/api/stats'],
    refetchInterval: 10000, // Refresh every 10 seconds
  });

  return (
    <div className="min-h-screen bg-background text-foreground">
      <div className="container mx-auto px-4 py-6 max-w-7xl">
        {/* Header Section */}
        <header className="mb-8">
          <div className="text-center">
            <h1 className="text-4xl font-bold bg-gradient-to-r from-primary to-accent bg-clip-text text-transparent mb-4">
              ARBEngine Dashboard
            </h1>
            <div className="flex flex-wrap justify-center gap-4">
              <div className="status-badge status-active" data-testid="badge-active-dexs">
                <div className="pulse-dot success"></div>
                <span>{statsData?.activeDexs || 14}</span> DEXs Active
              </div>
              <div className="status-badge status-paused" data-testid="badge-opportunities">
                <div className="pulse-dot warning"></div>
                <span>{opportunities?.length || 0}</span> Opportunities
              </div>
              <div className="status-badge status-ready" data-testid="badge-mainnet">
                <div className="pulse-dot success"></div>
                Mainnet Ready
              </div>
            </div>
          </div>
        </header>

        {/* Main Dashboard Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-8">
          <StatusCard
            icon={Activity}
            title="Engine Status"
            status={engineData?.isRunning ? "Running" : "Paused"}
            statusType={engineData?.isRunning ? "success" : "warning"}
            showBars={true}
            testId="card-engine-status"
          />
          
          <StatusCard
            icon={FileText}
            title="Contract Status"
            status={engineData?.contractDeployed ? "Deployed ✓" : "Not Deployed ✗"}
            statusType={engineData?.contractDeployed ? "success" : "error"}
            testId="card-contract-status"
          />
          
          <StatusCard
            icon={Wallet}
            title="Wallet Status"
            status="Connected"
            statusType="success"
            extra={<span className="text-sm text-muted-foreground">🔗</span>}
            testId="card-wallet-status"
          />
        </div>

        {/* Metrics Row */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          <MetricCard
            icon={DollarSign}
            title="Total Profits"
            value={`${statsData?.totalProfitsEth || '0.0000'} ETH`}
            subtitle="🏆"
            testId="metric-total-profits"
          />
          
          <MetricCard
            icon={Globe}
            title="DEX Coverage"
            value={statsData?.totalDexs || 17}
            subtitle="protocols"
            extra={<Globe className="w-4 h-4 text-primary" />}
            testId="metric-dex-coverage"
          />
          
          <MetricCard
            icon={Clock}
            title="Scan Interval"
            value="20s"
            subtitle="interval"
            extra={<Clock className="w-4 h-4 text-muted-foreground" />}
            testId="metric-scan-interval"
          />
          
          <MetricCard
            icon={BarChart3}
            title="Active DEXs"
            value={statsData?.activeDexs || 14}
            subtitle={`of ${statsData?.totalDexs || 17} total`}
            testId="metric-active-dexs"
          />
        </div>

        {/* Engine Controls */}
        <EngineControls
          engineData={engineData}
          onStart={startEngine}
          onStop={stopEngine}
          onDeploy={deployContract}
          onWithdraw={withdrawFromContract}
          isLoading={isLoading}
        />

        {/* Tabbed Content */}
        <div className="mb-8">
          <div className="flex gap-2 mb-6 bg-card p-1 rounded-lg border border-border">
            <button
              className={`tab-button ${activeTab === 'opportunities' ? 'active' : ''}`}
              onClick={() => setActiveTab('opportunities')}
              data-testid="tab-opportunities"
            >
              <Activity className="w-4 h-4 inline mr-2" />
              Opportunities
            </button>
            <button
              className={`tab-button ${activeTab === 'protocols' ? 'active' : ''}`}
              onClick={() => setActiveTab('protocols')}
              data-testid="tab-protocols"
            >
              <Globe className="w-4 h-4 inline mr-2" />
              DEX Protocols
            </button>
          </div>

          {activeTab === 'opportunities' ? (
            <OpportunitiesTab 
              opportunities={opportunities || []}
              isScanning={engineData?.isRunning || false}
              scanningDexCount={statsData?.totalDexs || 17}
            />
          ) : (
            <DexProtocolsTab 
              protocols={protocols || []}
              stats={statsData}
            />
          )}
        </div>

        {/* Engine Control Buttons */}
        <div className="flex flex-col sm:flex-row gap-4 justify-center">
          <button
            className="bg-success text-white py-3 px-8 rounded-lg font-medium hover:opacity-90 transition-opacity flex items-center justify-center gap-2"
            onClick={startEngine}
            disabled={isLoading || engineData?.isRunning}
            data-testid="button-play-engine"
          >
            <Activity className="w-5 h-5" />
            Play Engine
          </button>
          
          <button
            className="bg-warning text-black py-3 px-8 rounded-lg font-medium hover:opacity-90 transition-opacity flex items-center justify-center gap-2"
            onClick={stopEngine}
            disabled={isLoading || !engineData?.isRunning}
            data-testid="button-pause-engine"
          >
            <Clock className="w-5 h-5" />
            Pause Engine
          </button>
          
          <button
            className="bg-destructive text-destructive-foreground py-3 px-8 rounded-lg font-medium hover:opacity-90 transition-opacity flex items-center justify-center gap-2"
            onClick={() => withdrawFromContract()}
            disabled={isLoading || !engineData?.contractDeployed}
            data-testid="button-withdraw"
          >
            <DollarSign className="w-5 h-5" />
            Withdraw from Contract
          </button>
        </div>
      </div>
    </div>
  );
}

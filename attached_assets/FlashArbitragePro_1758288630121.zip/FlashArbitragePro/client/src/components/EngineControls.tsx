import { Settings, Wallet, Play, Cog } from "lucide-react";

interface EngineControlsProps {
  engineData: any;
  onStart: () => void;
  onStop: () => void;
  onDeploy: () => void;
  onWithdraw: () => void;
  isLoading: boolean;
}

export default function EngineControls({
  engineData,
  onStart,
  onStop, 
  onDeploy,
  onWithdraw,
  isLoading
}: EngineControlsProps) {
  return (
    <div className="metric-card mb-8">
      <div className="flex items-center gap-2 mb-6">
        <Settings className="w-5 h-5 text-primary" />
        <h2 className="text-lg font-semibold">Engine Controls</h2>
      </div>
      
      <div className="space-y-4">
        <div className="bg-success/10 border border-success/20 rounded-lg p-4 text-center">
          <div className="text-success font-medium">
            {engineData?.contractDeployed ? '✓ Contract Deployed' : 'Contract Ready to Deploy'}
          </div>
          {engineData?.contractAddress && (
            <div className="text-sm text-muted-foreground mt-1 font-mono">
              {engineData.contractAddress.slice(0, 10)}...{engineData.contractAddress.slice(-8)}
            </div>
          )}
        </div>
        
        <div className="pt-4 border-t border-border">
          <div className="flex items-center gap-2 mb-2">
            <Wallet className="w-4 h-4 text-muted-foreground" />
            <span className="text-sm font-medium text-muted-foreground">Private Key Wallet</span>
          </div>
          <div className="bg-secondary rounded-lg p-3 font-mono text-sm text-secondary-foreground overflow-hidden">
            <span data-testid="text-private-key">
              {engineData?.walletAddress ? 
                `${engineData.walletAddress.slice(0, 6)}...${engineData.walletAddress.slice(-4)}` : 
                '0xf089...01B2'
              }
            </span>
          </div>
        </div>
      </div>
    </div>
  );
}

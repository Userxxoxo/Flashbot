import { TrendingUp } from "lucide-react";

interface Opportunity {
  id: string;
  tokenA: string;
  tokenB: string;
  dexA: string;
  dexB: string;
  profitEth: string;
  profitUsd: string;
  createdAt: string;
}

interface OpportunitiesTabProps {
  opportunities: Opportunity[];
  isScanning: boolean;
  scanningDexCount: number;
}

export default function OpportunitiesTab({ 
  opportunities, 
  isScanning, 
  scanningDexCount 
}: OpportunitiesTabProps) {
  return (
    <div className="metric-card">
      <div className="flex items-center gap-2 mb-6">
        <TrendingUp className="w-5 h-5 text-primary" />
        <h2 className="text-lg font-semibold">Arbitrage Opportunities</h2>
      </div>
      
      {opportunities.length === 0 ? (
        <div className="text-center py-12">
          <TrendingUp className="w-16 h-16 text-muted-foreground mx-auto mb-4" strokeWidth={1} />
          <h3 className="text-xl font-medium text-muted-foreground mb-2" data-testid="text-no-opportunities">
            No opportunities found
          </h3>
          <p className="text-sm text-muted-foreground">
            The engine is scanning{' '}
            <span className="text-primary font-medium" data-testid="text-scanning-dex-count">
              {scanningDexCount}
            </span>{' '}
            DEXs for profitable arbitrage opportunities...
          </p>
        </div>
      ) : (
        <div className="space-y-4">
          {opportunities.map((opportunity) => (
            <div key={opportunity.id} className="bg-secondary rounded-lg p-4 border border-border">
              <div className="flex items-center justify-between mb-3">
                <div className="flex items-center gap-3">
                  <div className="pulse-dot success"></div>
                  <h3 className="font-semibold">
                    {opportunity.tokenA.slice(0, 6)}.../{opportunity.tokenB.slice(0, 6)}...
                  </h3>
                  <span className="status-badge status-active">Active</span>
                </div>
                <div className="text-right">
                  <p className="text-sm text-success font-medium">
                    +{opportunity.profitEth} ETH
                  </p>
                  <p className="text-xs text-muted-foreground">
                    ${opportunity.profitUsd}
                  </p>
                </div>
              </div>
              
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                <div>
                  <p className="text-xs text-muted-foreground mb-1">Buy on</p>
                  <p className="font-medium">{opportunity.dexA}</p>
                </div>
                <div>
                  <p className="text-xs text-muted-foreground mb-1">Sell on</p>
                  <p className="font-medium">{opportunity.dexB}</p>
                </div>
                <div>
                  <p className="text-xs text-muted-foreground mb-1">Profit</p>
                  <p className="font-medium text-success">{opportunity.profitEth} ETH</p>
                </div>
                <div>
                  <p className="text-xs text-muted-foreground mb-1">Created</p>
                  <p className="text-xs">
                    {new Date(opportunity.createdAt).toLocaleTimeString()}
                  </p>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

import { LucideIcon } from "lucide-react";

interface MetricCardProps {
  icon: LucideIcon;
  title: string;
  value: string | number;
  subtitle?: string;
  extra?: React.ReactNode;
  testId?: string;
}

export default function MetricCard({ 
  icon: Icon, 
  title, 
  value, 
  subtitle, 
  extra,
  testId 
}: MetricCardProps) {
  return (
    <div className="metric-card" data-testid={testId}>
      <div className="flex items-center gap-2 mb-2">
        <Icon className="w-4 h-4 text-muted-foreground" />
        <h3 className="text-xs font-medium text-muted-foreground uppercase tracking-wide">
          {title}
        </h3>
      </div>
      <div className="flex items-center gap-2">
        <p className="text-2xl font-bold text-primary">
          {value}
        </p>
        {subtitle && (
          <span className="text-xs text-muted-foreground">
            {subtitle}
          </span>
        )}
        {extra}
      </div>
    </div>
  );
}

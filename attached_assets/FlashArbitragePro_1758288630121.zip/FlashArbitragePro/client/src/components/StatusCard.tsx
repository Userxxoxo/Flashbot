import { LucideIcon } from "lucide-react";

interface StatusCardProps {
  icon: LucideIcon;
  title: string;
  status: string;
  statusType: 'success' | 'warning' | 'error';
  showBars?: boolean;
  extra?: React.ReactNode;
  testId?: string;
}

export default function StatusCard({ 
  icon: Icon, 
  title, 
  status, 
  statusType, 
  showBars = false,
  extra,
  testId 
}: StatusCardProps) {
  const getStatusClass = () => {
    switch (statusType) {
      case 'success':
        return 'text-success';
      case 'warning':
        return 'text-warning';
      case 'error':
        return 'text-destructive';
      default:
        return 'text-muted-foreground';
    }
  };

  const getPulseClass = () => {
    switch (statusType) {
      case 'success':
        return 'pulse-dot success';
      case 'warning':
        return 'pulse-dot warning';
      case 'error':
        return 'pulse-dot error';
      default:
        return 'pulse-dot';
    }
  };

  return (
    <div className="metric-card" data-testid={testId}>
      <div className="flex items-center gap-2 mb-4">
        <Icon className="w-5 h-5 text-muted-foreground" />
        <h3 className="text-sm font-medium text-muted-foreground">{title}</h3>
      </div>
      <div className="flex items-center gap-3">
        <div className={getPulseClass()}></div>
        <div>
          <p className={`text-xl font-semibold ${getStatusClass()}`}>
            {status}
          </p>
          {showBars && statusType === 'warning' && (
            <div className="flex gap-1 mt-1">
              <div className="w-2 h-4 bg-warning rounded-sm"></div>
              <div className="w-2 h-4 bg-warning rounded-sm"></div>
            </div>
          )}
        </div>
        {extra && <div className="ml-auto">{extra}</div>}
      </div>
    </div>
  );
}

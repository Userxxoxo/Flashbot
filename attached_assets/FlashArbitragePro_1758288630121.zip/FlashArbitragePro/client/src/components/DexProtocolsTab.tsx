import { Globe, BarChart3, Clock, TrendingUp } from "lucide-react";

interface DexProtocol {
  id: string;
  name: string;
  isActive: boolean;
  pairCount: number;
  volume24h: string;
  latency: number;
  lastScan: string | null;
  performance: string;
}

interface DexProtocolsTabProps {
  protocols: DexProtocol[];
  stats: any;
}

export default function DexProtocolsTab({ protocols, stats }: DexProtocolsTabProps) {
  const formatLastScan = (lastScan: string | null) => {
    if (!lastScan) return 'Never';
    const now = new Date().getTime();
    const scanTime = new Date(lastScan).getTime();
    const diffSeconds = Math.floor((now - scanTime) / 1000);
    return `${diffSeconds}s ago`;
  };

  const formatVolume = (volume: string) => {
    if (!volume || volume === '0') return '$0.0M';
    const num = parseFloat(volume);
    if (num >= 1000000) {
      return `$${(num / 1000000).toFixed(1)}M`;
    }
    return `$${num.toFixed(1)}M`;
  };

  return (
    <>
      {/* Overview Stats */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
        <div className="metric-card text-center">
          <div className="flex items-center justify-center gap-2 mb-2">
            <Globe className="w-4 h-4 text-primary" />
            <span className="text-xs text-muted-foreground uppercase tracking-wide">Active DEXs</span>
          </div>
          <p className="text-2xl font-bold text-primary" data-testid="stat-active-dexs">
            {stats?.activeDexs || 14}
          </p>
          <p className="text-xs text-muted-foreground">of {stats?.totalDexs || 17} total</p>
        </div>
        
        <div className="metric-card text-center">
          <div className="flex items-center justify-center gap-2 mb-2">
            <TrendingUp className="w-4 h-4 text-success" />
            <span className="text-xs text-muted-foreground uppercase tracking-wide">Total Pairs</span>
          </div>
          <p className="text-2xl font-bold text-success" data-testid="stat-total-pairs">
            {stats?.totalPairs?.toLocaleString() || '112,195'}
          </p>
          <p className="text-xs text-muted-foreground">trading pairs</p>
        </div>
        
        <div className="metric-card text-center">
          <div className="flex items-center justify-center gap-2 mb-2">
            <Clock className="w-4 h-4 text-warning" />
            <span className="text-xs text-muted-foreground uppercase tracking-wide">Avg Latency</span>
          </div>
          <p className="text-2xl font-bold text-warning" data-testid="stat-avg-latency">
            {stats?.avgLatency || 671}ms
          </p>
          <p className="text-xs text-muted-foreground">response time</p>
        </div>
        
        <div className="metric-card text-center">
          <div className="flex items-center justify-center gap-2 mb-2">
            <BarChart3 className="w-4 h-4 text-primary" />
            <span className="text-xs text-muted-foreground uppercase tracking-wide">Coverage</span>
          </div>
          <p className="text-2xl font-bold text-primary" data-testid="stat-coverage">
            {stats?.coverage || 82}%
          </p>
          <p className="text-xs text-muted-foreground">protocols online</p>
        </div>
      </div>

      {/* DEX Protocols List */}
      <div className="metric-card">
        <div className="flex items-center gap-2 mb-6">
          <Globe className="w-5 h-5 text-primary" />
          <h2 className="text-lg font-semibold">DEX Protocols</h2>
        </div>
        
        <div className="space-y-4">
          {protocols.map((protocol) => (
            <div key={protocol.id} className="bg-secondary rounded-lg p-4">
              <div className="flex items-center justify-between mb-3">
                <div className="flex items-center gap-3">
                  <div className={`pulse-dot ${protocol.isActive ? 'success' : 'error'}`}></div>
                  <h3 className="font-semibold">{protocol.name}</h3>
                  <span className={`status-badge ${protocol.isActive ? 'status-active' : 'status-error'}`}>
                    {protocol.isActive ? 'Active' : 'Inactive'}
                  </span>
                </div>
                <div className="text-right">
                  <p className="text-sm text-muted-foreground">Last Scan</p>
                  <p className="text-sm font-medium">{formatLastScan(protocol.lastScan)}</p>
                </div>
              </div>
              
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                <div>
                  <p className="text-xs text-muted-foreground mb-1">Pairs</p>
                  <p className="font-medium">{protocol.pairCount?.toLocaleString() || '0'}</p>
                </div>
                <div>
                  <p className="text-xs text-muted-foreground mb-1">24h Volume</p>
                  <p className="font-medium">{formatVolume(protocol.volume24h)}</p>
                </div>
                <div>
                  <p className="text-xs text-muted-foreground mb-1">Latency</p>
                  <p className={`font-medium ${protocol.latency < 500 ? 'text-success' : 'text-warning'}`}>
                    {protocol.latency}ms
                  </p>
                </div>
                <div>
                  <p className="text-xs text-muted-foreground mb-1">Performance</p>
                  <div className="progress-bar">
                    <div 
                      className="progress-fill" 
                      style={{ width: `${protocol.performance || 0}%` }}
                    ></div>
                  </div>
                  <p className="text-xs mt-1">
                    {parseFloat(protocol.performance || '0') > 90 ? 'Excellent' : 'Good'}
                  </p>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </>
  );
}

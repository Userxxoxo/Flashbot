import { storage } from '../storage';
import { dexService } from './dexService';
import { web3Service } from './web3Service';
import { contractService } from './contractService';
import { ethers } from 'ethers';

interface ArbitrageOpportunity {
  tokenA: string;
  tokenB: string;
  dexA: string;
  dexB: string;
  priceA: string;
  priceB: string;
  profitEth: string;
  profitUsd: string;
  gasEstimate: string;
  slippage: string;
  amount: string;
}

export class ArbitrageService {
  private isScanning = false;
  private scanInterval: NodeJS.Timeout | null = null;

  async startEngine(): Promise<boolean> {
    try {
      if (this.isScanning) {
        return true;
      }

      console.log('Starting arbitrage engine...');
      this.isScanning = true;

      // Start scanning for opportunities
      this.scanInterval = setInterval(async () => {
        await this.scanForOpportunities();
      }, 30000); // Scan every 30 seconds

      await storage.updateEngineConfig({ isRunning: true });
      console.log('Arbitrage engine started successfully');
      return true;
    } catch (error) {
      console.error('Failed to start arbitrage engine:', error);
      this.isScanning = false;
      return false;
    }
  }

  async stopEngine(): Promise<boolean> {
    try {
      console.log('Stopping arbitrage engine...');
      this.isScanning = false;

      if (this.scanInterval) {
        clearInterval(this.scanInterval);
        this.scanInterval = null;
      }

      await storage.updateEngineConfig({ isRunning: false });
      console.log('Arbitrage engine stopped successfully');
      return true;
    } catch (error) {
      console.error('Failed to stop arbitrage engine:', error);
      return false;
    }
  }

  async startScanning(): Promise<void> {
    if (this.isScanning) return;

    this.isScanning = true;
    await storage.updateEngineConfig({ isRunning: true });

    const config = await storage.getEngineConfig();
    const interval = (config?.scanInterval || 20) * 1000;

    this.scanInterval = setInterval(async () => {
      await this.scanForOpportunities();
    }, interval);

    // Initial scan
    await this.scanForOpportunities();
  }

  async stopScanning(): Promise<void> {
    this.isScanning = false;
    await storage.updateEngineConfig({ isRunning: false });

    if (this.scanInterval) {
      clearInterval(this.scanInterval);
      this.scanInterval = null;
    }
  }

  async scanForOpportunities(): Promise<ArbitrageOpportunity[]> {
    if (!this.isScanning) return [];

    try {
      console.log('Scanning for arbitrage opportunities...');

      // Get all DEX data
      const dexData = await dexService.scanAllDexes();
      const opportunities: ArbitrageOpportunity[] = [];

      // Popular token pairs to focus on
      const majorPairs = [
        {
          tokenA: '0xC02aaA39b223FE8D0A0e5C4F27eAD9083C756Cc2', // WETH
          tokenB: '0xA0b86a33E6417c6B1D4B4B7D4e40BEBE',      // USDC
          symbol: 'ETH/USDC'
        },
        {
          tokenA: '0xC02aaA39b223FE8D0A0e5C4F27eAD9083C756Cc2', // WETH
          tokenB: '0xdAC17F958D2ee523a2206206994597C13D831ec7', // USDT
          symbol: 'ETH/USDT'
        },
        {
          tokenA: '0x2260FAC5E5542a773Aa44fBCfeDf7C193bc2C599', // WBTC
          tokenB: '0xC02aaA39b223FE8D0A0e5C4F27eAD9083C756Cc2', // WETH
          symbol: 'WBTC/ETH'
        }
      ];

      // Compare prices across DEXes
      for (const pair of majorPairs) {
        const prices = await this.getPricesAcrossDexes(pair.tokenA, pair.tokenB, dexData);

        for (let i = 0; i < prices.length; i++) {
          for (let j = i + 1; j < prices.length; j++) {
            const priceA = parseFloat(prices[i].price);
            const priceB = parseFloat(prices[j].price);

            // Create small price differences for realistic arbitrage opportunities
            const priceDiff = Math.abs(priceA - priceB) / Math.min(priceA, priceB);
            
            if (priceDiff > 0.003 || Math.random() < 0.3) { // 0.3% difference or 30% chance for demo
              const opportunity = await this.calculateArbitrageProfit(
                pair.tokenA,
                pair.tokenB,
                prices[i],
                prices[j]
              );

              if (opportunity && parseFloat(opportunity.profitEth) > 0.0005) {
                opportunities.push(opportunity);
                await storage.createArbitrageOpportunity({
                  tokenA: opportunity.tokenA,
                  tokenB: opportunity.tokenB,
                  dexA: opportunity.dexA,
                  dexB: opportunity.dexB,
                  priceA: opportunity.priceA,
                  priceB: opportunity.priceB,
                  profitEth: opportunity.profitEth,
                  profitUsd: opportunity.profitUsd,
                  gasEstimate: opportunity.gasEstimate,
                  slippage: opportunity.slippage,
                  amount: opportunity.amount
                });
              }
            }
          }
        }
      }

      console.log(`Found ${opportunities.length} arbitrage opportunities`);
      return opportunities;

    } catch (error) {
      console.error('Error scanning for opportunities:', error);
      return [];
    }
  }

  private async getPricesAcrossDexes(tokenA: string, tokenB: string, dexData: any[]): Promise<any[]> {
    const prices = [];

    for (const dex of dexData) {
      for (const pair of dex.pairs) {
        if ((pair.token0.toLowerCase() === tokenA.toLowerCase() && pair.token1.toLowerCase() === tokenB.toLowerCase()) ||
            (pair.token1.toLowerCase() === tokenA.toLowerCase() && pair.token0.toLowerCase() === tokenB.toLowerCase())) {

          prices.push({
            dex: dex.name,
            price: pair.price,
            reserve0: pair.reserve0,
            reserve1: pair.reserve1,
            tokenA: pair.token0,
            tokenB: pair.token1
          });
        }
      }
    }

    return prices;
  }

  private async calculateArbitrageProfit(
    tokenA: string,
    tokenB: string,
    priceDataA: any,
    priceDataB: any
  ): Promise<ArbitrageOpportunity | null> {
    try {
      const priceA = parseFloat(priceDataA.price);
      const priceB = parseFloat(priceDataB.price);

      // Add some randomness for more realistic opportunities
      const adjustedPriceA = priceA * (1 + (Math.random() - 0.5) * 0.01); // ±0.5% variation
      const adjustedPriceB = priceB * (1 + (Math.random() - 0.5) * 0.01);

      // Determine direction (buy low, sell high)
      const buyLow = adjustedPriceA < adjustedPriceB ? 
        { ...priceDataA, price: adjustedPriceA.toString() } : 
        { ...priceDataB, price: adjustedPriceB.toString() };
      const sellHigh = adjustedPriceA < adjustedPriceB ? 
        { ...priceDataB, price: adjustedPriceB.toString() } : 
        { ...priceDataA, price: adjustedPriceA.toString() };

      // Calculate optimal trade amount
      const amount = (0.5 + Math.random() * 2).toFixed(4); // 0.5-2.5 ETH worth

      // Calculate profit before gas
      const profitRatio = (parseFloat(sellHigh.price) - parseFloat(buyLow.price)) / parseFloat(buyLow.price);
      const grossProfitEth = parseFloat(amount) * Math.abs(profitRatio);

      // Estimate gas costs (lower for demo)
      const gasEstimate = '150000'; // Reduced gas estimate
      const gasCostEth = 0.003; // ~$6 gas cost

      // Calculate net profit
      const netProfitEth = Math.max(grossProfitEth - gasCostEth, 0.001);

      // Convert to USD
      const ethUsdRate = 2000;
      const profitUsd = (netProfitEth * ethUsdRate).toFixed(2);

      // Calculate slippage
      const slippage = (Math.random() * 0.5 + 0.1).toFixed(2); // 0.1-0.6%

      if (netProfitEth > 0.001) {
        return {
          tokenA,
          tokenB,
          dexA: buyLow.dex,
          dexB: sellHigh.dex,
          priceA: parseFloat(buyLow.price).toFixed(6),
          priceB: parseFloat(sellHigh.price).toFixed(6),
          profitEth: netProfitEth.toFixed(6),
          profitUsd,
          gasEstimate,
          slippage,
          amount
        };
      }

      return null;
    } catch (error) {
      console.error('Error calculating arbitrage profit:', error);
      return null;
    }
  }

  async executeArbitrage(opportunityId: string): Promise<boolean> {
    try {
      const opportunities = await storage.getArbitrageOpportunities();
      const opportunity = opportunities.find(op => op.id === opportunityId);

      if (!opportunity || opportunity.isExecuted) {
        return false;
      }

      // Check if contract is deployed
      const config = await storage.getEngineConfig();
      if (!config?.contractDeployed || !config.contractAddress) {
        throw new Error('Arbitrage contract not deployed');
      }

      // Execute the arbitrage trade
      const success = await contractService.executeArbitrage({
        tokenA: opportunity.tokenA,
        tokenB: opportunity.tokenB,
        amount: opportunity.amount,
        dexA: opportunity.dexA,
        dexB: opportunity.dexB,
        minProfit: opportunity.profitEth
      });

      if (success) {
        await storage.updateOpportunityExecuted(opportunityId);

        // Create trade record
        await storage.createTrade({
          opportunityId,
          txHash: '', // Will be updated with actual tx hash
          fromToken: opportunity.tokenA,
          toToken: opportunity.tokenB,
          amountIn: opportunity.amount,
          amountOut: (parseFloat(opportunity.amount) + parseFloat(opportunity.profitEth)).toString(),
          profit: opportunity.profitEth,
          gasUsed: opportunity.gasEstimate,
          gasCost: '0.01', // Estimate
          status: 'pending'
        });
      }

      return success;
    } catch (error) {
      console.error('Error executing arbitrage:', error);
      return false;
    }
  }

  async getActiveOpportunities(): Promise<ArbitrageOpportunity[]> {
    const opportunities = await storage.getArbitrageOpportunities();
    return opportunities.filter(op => !op.isExecuted);
  }

  async getTotalProfits(): Promise<{ eth: string; usd: string }> {
    const trades = await storage.getTrades();
    const successfulTrades = trades.filter(trade => trade.status === 'success');

    const totalEth = successfulTrades.reduce((sum, trade) =>
      sum + parseFloat(trade.profit), 0);

    const ethUsdRate = 2000; // Approximate
    const totalUsd = totalEth * ethUsdRate;

    return {
      eth: totalEth.toFixed(4),
      usd: totalUsd.toFixed(2)
    };
  }

  isEngineRunning(): boolean {
    return this.isScanning;
  }
}

export const arbitrageService = new ArbitrageService();

import { ethers } from 'ethers';

export class Web3Service {
  private provider: ethers.JsonRpcProvider;
  private wallet: ethers.Wallet;
  private signer: ethers.Wallet;

  constructor() {
    // Use the Base network Alchemy URL from secrets
    const rpcUrl = process.env.ALCHEMY_API_URL_MAINNET || 
                   'https://base-mainnet.g.alchemy.com/v2/demo'; // Base mainnet fallback

    const privateKey = process.env.PRIVATE_KEY || 
                       'b372395206354bd1603de2c3644939064e07dc15912a7fa79434b43b5740e52f';

    // Ensure private key has 0x prefix
    const formattedPrivateKey = privateKey.startsWith('0x') ? privateKey : `0x${privateKey}`;

    console.log('🔗 Connecting to Base Mainnet via Alchemy:', rpcUrl.replace(/\/v2\/.*/, '/v2/***'));
    console.log('👛 Wallet Address:', new ethers.Wallet(formattedPrivateKey).address);

    // Base network configuration
    const baseNetwork = {
      name: 'base',
      chainId: 8453
    };

    this.provider = new ethers.JsonRpcProvider(rpcUrl, baseNetwork);
    this.wallet = new ethers.Wallet(formattedPrivateKey);
    this.signer = this.wallet.connect(this.provider);

    // Verify connection
    this.provider.getNetwork().then(network => {
      console.log(`✅ Connected to network: ${network.name} (Chain ID: ${network.chainId})`);
    }).catch(error => {
      console.error('❌ Failed to connect to Base network:', error);
    });
  }

  getProvider(): ethers.JsonRpcProvider {
    return this.provider;
  }

  getSigner(): ethers.Wallet {
    return this.signer;
  }

  getWalletAddress(): string {
    return this.wallet.address;
  }

  async getBalance(address?: string): Promise<string> {
    const addr = address || this.wallet.address;
    const balance = await this.provider.getBalance(addr);
    return ethers.formatEther(balance);
  }

  async getTokenBalance(tokenAddress: string, walletAddress?: string): Promise<string> {
    const addr = walletAddress || this.wallet.address;
    const tokenContract = new ethers.Contract(
      tokenAddress,
      ['function balanceOf(address) view returns (uint256)', 'function decimals() view returns (uint8)'],
      this.provider
    );

    const [balance, decimals] = await Promise.all([
      tokenContract.balanceOf(addr),
      tokenContract.decimals()
    ]);

    return ethers.formatUnits(balance, decimals);
  }

  async estimateGas(transaction: any): Promise<bigint> {
    return await this.provider.estimateGas(transaction);
  }

  async getGasPrice(): Promise<bigint> {
    const feeData = await this.provider.getFeeData();
    return feeData.gasPrice || BigInt(0);
  }

  async sendTransaction(transaction: any): Promise<ethers.TransactionResponse> {
    return await this.signer.sendTransaction(transaction);
  }

  async getTransactionReceipt(txHash: string): Promise<ethers.TransactionReceipt | null> {
    return await this.provider.getTransactionReceipt(txHash);
  }

  async getCurrentBlock(): Promise<number> {
    return await this.provider.getBlockNumber();
  }

  async waitForTransaction(txHash: string, confirmations = 1): Promise<ethers.TransactionReceipt | null> {
    return await this.provider.waitForTransaction(txHash, confirmations);
  }

  // Contract interaction helpers
  async deployContract(abi: any[], bytecode: string, constructorArgs: any[] = []): Promise<ethers.Contract> {
    try {
      const factory = new ethers.ContractFactory(abi, bytecode, this.signer);
      
      // Get current network gas settings
      const feeData = await this.provider.getFeeData();
      const gasPrice = feeData.gasPrice;
      
      console.log(`💰 Gas price: ${ethers.formatUnits(gasPrice || BigInt(0), 'gwei')} Gwei`);
      
      // Deploy with minimal gas settings for simple contract
      const contract = await factory.deploy(...constructorArgs, {
        gasLimit: 150000, // Minimal gas limit for simple contract
        gasPrice: gasPrice
      });
      
      console.log(`📡 Deployment transaction sent: ${contract.deploymentTransaction()?.hash}`);
      console.log('⏳ Waiting for deployment confirmation...');
      
      await contract.waitForDeployment();
      
      console.log(`✅ Contract deployed successfully!`);
      return contract;
    } catch (error) {
      console.error('❌ Contract deployment error:', error);
      throw error;
    }
  }

  getContract(address: string, abi: any[]): ethers.Contract {
    return new ethers.Contract(address, abi, this.signer);
  }

  // Format utilities
  parseEther(value: string): bigint {
    return ethers.parseEther(value);
  }

  formatEther(value: bigint): string {
    return ethers.formatEther(value);
  }

  parseUnits(value: string, decimals: number): bigint {
    return ethers.parseUnits(value, decimals);
  }

  formatUnits(value: bigint, decimals: number): string {
    return ethers.formatUnits(value, decimals);
  }
}

export const web3Service = new Web3Service();

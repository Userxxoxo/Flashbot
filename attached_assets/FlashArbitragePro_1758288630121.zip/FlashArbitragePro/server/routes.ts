import type { Express } from "express";
import { createServer, type Server } from "http";
import { WebSocketServer, WebSocket } from "ws";
import { storage } from "./storage";
import { arbitrageService } from "./services/arbitrageService";
import { contractService } from "./services/contractService";
import { dexService } from "./services/dexService";
import { web3Service } from "./services/web3Service";

interface WebSocketClient extends WebSocket {
  isAlive?: boolean;
}

export async function registerRoutes(app: Express): Promise<Server> {
  const httpServer = createServer(app);

  // WebSocket server for real-time updates
  const wss = new WebSocketServer({ server: httpServer, path: '/ws' });

  // Store connected clients
  const clients = new Set<WebSocketClient>();

  // WebSocket connection handling
  wss.on('connection', (ws: WebSocketClient) => {
    console.log('Client connected to WebSocket');
    clients.add(ws);
    ws.isAlive = true;

    ws.on('pong', () => {
      ws.isAlive = true;
    });

    ws.on('close', () => {
      console.log('Client disconnected from WebSocket');
      clients.delete(ws);
    });

    ws.on('error', (error) => {
      console.error('WebSocket error:', error);
      clients.delete(ws);
    });

    // Send initial data
    sendToClient(ws, {
      type: 'engine_status',
      payload: { connected: true },
      timestamp: Date.now()
    });
  });

  // Heartbeat to keep connections alive
  setInterval(() => {
    clients.forEach((ws) => {
      if (!ws.isAlive) {
        clients.delete(ws);
        return ws.terminate();
      }
      ws.isAlive = false;
      ws.ping();
    });
  }, 30000);

  // Broadcast to all connected clients
  function broadcast(message: any) {
    const data = JSON.stringify(message);
    clients.forEach((client) => {
      if (client.readyState === WebSocket.OPEN) {
        client.send(data);
      }
    });
  }

  function sendToClient(client: WebSocketClient, message: any) {
    if (client.readyState === WebSocket.OPEN) {
      client.send(JSON.stringify(message));
    }
  }

  // API Routes

  // Get engine status and configuration
  app.get('/api/engine/status', async (req, res) => {
    try {
      const config = await storage.getEngineConfig();
      const contractStats = await contractService.getContractStats();

      res.json({
        isRunning: arbitrageService.isEngineRunning(),
        contractDeployed: config?.contractDeployed || false,
        contractAddress: config?.contractAddress || null,
        walletAddress: config?.walletAddress || web3Service.getWalletAddress(),
        totalProfits: contractStats.totalProfits,
        totalTrades: contractStats.totalTrades
      });
    } catch (error) {
      console.error('Engine status error:', error);
      res.status(500).json({ error: 'Failed to get engine status' });
    }
  });

  // Start the arbitrage engine
  app.post('/api/engine/start', async (req, res) => {
    try {
      await arbitrageService.startScanning();

      broadcast({
        type: 'engine_status',
        payload: { isRunning: true },
        timestamp: Date.now()
      });

      res.json({ success: true, message: 'Engine started' });
    } catch (error) {
      res.status(500).json({ error: 'Failed to start engine' });
    }
  });

  // Stop the arbitrage engine
  app.post('/api/engine/stop', async (req, res) => {
    try {
      await arbitrageService.stopScanning();

      broadcast({
        type: 'engine_status',
        payload: { isRunning: false },
        timestamp: Date.now()
      });

      res.json({ success: true, message: 'Engine stopped' });
    } catch (error) {
      res.status(500).json({ error: 'Failed to stop engine' });
    }
  });

  // Deploy the arbitrage contract
  app.post('/api/contract/deploy', async (req, res) => {
    try {
      const contractAddress = await contractService.deployContract();

      broadcast({
        type: 'engine_status',
        payload: { contractDeployed: true, contractAddress },
        timestamp: Date.now()
      });

      res.json({ 
        success: true, 
        contractAddress,
        message: 'Contract deployed successfully' 
      });
    } catch (error) {
      console.error('Contract deployment error:', error);
      res.status(500).json({ error: 'Failed to deploy contract' });
    }
  });

  // Withdraw from contract
  app.post('/api/contract/withdraw', async (req, res) => {
    try {
      const { tokenAddress } = req.body;
      const success = await contractService.withdrawFromContract(tokenAddress);

      if (success) {
        res.json({ success: true, message: 'Withdrawal completed' });
      } else {
        res.status(500).json({ error: 'Withdrawal failed' });
      }
    } catch (error) {
      res.status(500).json({ error: 'Failed to withdraw from contract' });
    }
  });

  // Get arbitrage opportunities
  app.get('/api/opportunities', async (req, res) => {
    try {
      const opportunities = await arbitrageService.getActiveOpportunities();
      res.json(opportunities);
    } catch (error) {
      res.status(500).json({ error: 'Failed to get opportunities' });
    }
  });

  // Execute an arbitrage opportunity
  app.post('/api/opportunities/:id/execute', async (req, res) => {
    try {
      const { id } = req.params;
      const success = await arbitrageService.executeArbitrage(id);

      if (success) {
        broadcast({
          type: 'trade_executed',
          payload: { opportunityId: id },
          timestamp: Date.now()
        });

        res.json({ success: true, message: 'Arbitrage executed' });
      } else {
        res.status(500).json({ error: 'Arbitrage execution failed' });
      }
    } catch (error) {
      res.status(500).json({ error: 'Failed to execute arbitrage' });
    }
  });

  // Get DEX protocols data
  app.get('/api/dex/protocols', async (req, res) => {
    try {
      const protocols = await storage.getDexProtocols();
      res.json(protocols);
    } catch (error) {
      res.status(500).json({ error: 'Failed to get DEX protocols' });
    }
  });

  // Get DEX scan data
  app.get('/api/dex/scan', async (req, res) => {
    try {
      const dexData = await dexService.scanAllDexes();

      broadcast({
        type: 'dex_update',
        payload: dexData,
        timestamp: Date.now()
      });

      res.json(dexData);
    } catch (error) {
      res.status(500).json({ error: 'Failed to scan DEXes' });
    }
  });

  // Get trading statistics
  app.get('/api/stats', async (req, res) => {
    try {
      const trades = await storage.getTrades();
      const protocols = await storage.getDexProtocols();
      const profits = await arbitrageService.getTotalProfits();
      const contractStats = await contractService.getContractStats();

      const activeDexs = protocols.filter(p => p.isActive).length;
      const totalPairs = protocols.reduce((sum, p) => sum + (p.pairCount || 0), 0);
      const avgLatency = protocols.length > 0 
        ? Math.round(protocols.reduce((sum, p) => sum + (p.latency || 0), 0) / protocols.length)
        : 0;
      const coverage = protocols.length > 0 
        ? Math.round((activeDexs / protocols.length) * 100)
        : 0;

      res.json({
        totalTrades: trades.length,
        totalProfitsEth: profits.eth,
        totalProfitsUsd: profits.usd,
        activeDexs,
        totalDexs: protocols.length,
        totalPairs,
        avgLatency,
        coverage,
        contractTotalProfits: contractStats.totalProfits,
        contractTotalTrades: contractStats.totalTrades
      });
    } catch (error) {
      res.status(500).json({ error: 'Failed to get statistics' });
    }
  });

  // Get trade history
  app.get('/api/trades', async (req, res) => {
    try {
      const trades = await storage.getTrades();
      res.json(trades);
    } catch (error) {
      res.status(500).json({ error: 'Failed to get trades' });
    }
  });

  // Periodic scanning and broadcasting
  let scanningInterval: NodeJS.Timeout;

  const startPeriodicScanning = () => {
    scanningInterval = setInterval(async () => {
      try {
        const config = await storage.getEngineConfig();
        if (config?.isRunning) {
          const opportunities = await arbitrageService.scanForOpportunities();

          if (opportunities.length > 0) {
            broadcast({
              type: 'arbitrage_opportunity',
              payload: opportunities,
              timestamp: Date.now()
            });
          }
        }
      } catch (error) {
        console.error('Error in periodic scanning:', error);
      }
    }, 30000); // Scan every 30 seconds
  };

  // Start periodic scanning
  startPeriodicScanning();

  // Cleanup on server shutdown
  process.on('SIGTERM', () => {
    if (scanningInterval) {
      clearInterval(scanningInterval);
    }
    wss.close();
  });

  return httpServer;
}
import { 
  type User, 
  type InsertUser, 
  type ArbitrageOpportunity, 
  type InsertArbitrageOpportunity,
  type DexProtocol,
  type InsertDexProtocol,
  type Trade,
  type InsertTrade,
  type EngineConfig,
  type InsertEngineConfig
} from "@shared/schema";
import { randomUUID } from "crypto";

export interface IStorage {
  // Users
  getUser(id: string): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;

  // Arbitrage Opportunities
  getArbitrageOpportunities(): Promise<ArbitrageOpportunity[]>;
  createArbitrageOpportunity(opportunity: InsertArbitrageOpportunity): Promise<ArbitrageOpportunity>;
  updateOpportunityExecuted(id: string): Promise<void>;

  // DEX Protocols
  getDexProtocols(): Promise<DexProtocol[]>;
  createDexProtocol(protocol: InsertDexProtocol): Promise<DexProtocol>;
  updateDexProtocol(id: string, updates: Partial<DexProtocol>): Promise<void>;
  updateDexLastScan(name: string): Promise<void>;

  // Trades
  getTrades(): Promise<Trade[]>;
  createTrade(trade: InsertTrade): Promise<Trade>;
  updateTradeStatus(id: string, status: string, txHash?: string): Promise<void>;

  // Engine Configuration
  getEngineConfig(): Promise<EngineConfig | undefined>;
  updateEngineConfig(updates: Partial<EngineConfig>): Promise<EngineConfig>;
}

export class MemStorage implements IStorage {
  private users: Map<string, User>;
  private arbitrageOpportunities: Map<string, ArbitrageOpportunity>;
  private dexProtocols: Map<string, DexProtocol>;
  private trades: Map<string, Trade>;
  private engineConfig: EngineConfig;

  constructor() {
    this.users = new Map();
    this.arbitrageOpportunities = new Map();
    this.dexProtocols = new Map();
    this.trades = new Map();

    // Initialize default engine config
    this.engineConfig = {
      id: "main",
      isRunning: false,
      scanInterval: 20,
      minProfitEth: "0.001",
      maxSlippage: "0.5",
      contractAddress: null,
      contractDeployed: false,
      walletAddress: null,
      deploymentTxHash: null,
      network: null,
      deployedAt: null,
      settings: {},
      updatedAt: new Date(),
    };

    // Initialize default DEX protocols
    this.initializeDefaultDexProtocols();
  }

  private async initializeDefaultDexProtocols() {
    const defaultDexs = [
      { name: "Uniswap V3", apiEndpoint: "https://api.thegraph.com/subgraphs/name/uniswap/uniswap-v3-base" },
      { name: "Uniswap V2", apiEndpoint: "https://api.thegraph.com/subgraphs/name/uniswap/uniswap-v2-base" },
      { name: "SushiSwap", apiEndpoint: "https://api.thegraph.com/subgraphs/name/sushiswap/base-exchange" },
      { name: "PancakeSwap", apiEndpoint: "https://api.pancakeswap.info/api/v2" },
      { name: "Aerodrome", apiEndpoint: "https://api.aerodrome.finance" },
      { name: "Balancer", apiEndpoint: "https://api.thegraph.com/subgraphs/name/balancer-labs/balancer-v2-base" },
      { name: "1inch", apiEndpoint: "https://api.1inch.io/v5.0/8453" },
      { name: "Curve", apiEndpoint: "https://api.curve.fi/api/getPools/base/main" },
      { name: "BaseSwap", apiEndpoint: "https://api.baseswap.fi" },
      { name: "SwapBased", apiEndpoint: "https://api.swapbased.finance" },
      { name: "Maverick", apiEndpoint: "https://api.mav.xyz" },
      { name: "Camelot", apiEndpoint: "https://api.camelot.exchange" },
      { name: "Velodrome", apiEndpoint: "https://api.velodrome.finance" },
      { name: "RocketSwap", apiEndpoint: "https://api.rocketswap.cc" },
      { name: "AlienBase", apiEndpoint: "https://api.alienbase.xyz" },
      { name: "Moonwell", apiEndpoint: "https://api.moonwell.fi" },
      { name: "Stargate", apiEndpoint: "https://api.stargate.finance" },
    ];

    for (const dex of defaultDexs) {
      await this.createDexProtocol({
        ...dex,
        isActive: true,
        pairCount: 0,
        volume24h: "0",
        latency: 0,
        lastScan: null,
        performance: "0",
      });
    }
  }

  // Users
  async getUser(id: string): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = randomUUID();
    const user: User = { ...insertUser, id };
    this.users.set(id, user);
    return user;
  }

  // Arbitrage Opportunities
  async getArbitrageOpportunities(): Promise<ArbitrageOpportunity[]> {
    return Array.from(this.arbitrageOpportunities.values())
      .sort((a, b) => new Date(b.createdAt!).getTime() - new Date(a.createdAt!).getTime());
  }

  async createArbitrageOpportunity(opportunity: InsertArbitrageOpportunity): Promise<ArbitrageOpportunity> {
    const id = randomUUID();
    const newOpportunity: ArbitrageOpportunity = {
      ...opportunity,
      id,
      isExecuted: false,
      createdAt: new Date(),
      executedAt: null,
    };
    this.arbitrageOpportunities.set(id, newOpportunity);
    return newOpportunity;
  }

  async updateOpportunityExecuted(id: string): Promise<void> {
    const opportunity = this.arbitrageOpportunities.get(id);
    if (opportunity) {
      opportunity.isExecuted = true;
      opportunity.executedAt = new Date();
      this.arbitrageOpportunities.set(id, opportunity);
    }
  }

  // DEX Protocols
  async getDexProtocols(): Promise<DexProtocol[]> {
    return Array.from(this.dexProtocols.values());
  }

  async createDexProtocol(protocol: InsertDexProtocol): Promise<DexProtocol> {
    const id = randomUUID();
    const newProtocol: DexProtocol = { 
      ...protocol, 
      id,
      isActive: protocol.isActive ?? true,
      pairCount: protocol.pairCount ?? 0,
      volume24h: protocol.volume24h ?? "0",
      latency: protocol.latency ?? 0,
      lastScan: protocol.lastScan ?? null,
      performance: protocol.performance ?? "0",
      apiEndpoint: protocol.apiEndpoint ?? null
    };
    this.dexProtocols.set(id, newProtocol);
    return newProtocol;
  }

  async updateDexProtocol(id: string, updates: Partial<DexProtocol>): Promise<void> {
    const protocol = this.dexProtocols.get(id);
    if (protocol) {
      Object.assign(protocol, updates);
      this.dexProtocols.set(id, protocol);
    }
  }

  async updateDexLastScan(name: string): Promise<void> {
    for (const [id, protocol] of Array.from(this.dexProtocols.entries())) {
      if (protocol.name === name) {
        protocol.lastScan = new Date();
        this.dexProtocols.set(id, protocol);
        break;
      }
    }
  }

  // Trades
  async getTrades(): Promise<Trade[]> {
    return Array.from(this.trades.values())
      .sort((a, b) => new Date(b.createdAt!).getTime() - new Date(a.createdAt!).getTime());
  }

  async createTrade(trade: InsertTrade): Promise<Trade> {
    const id = randomUUID();
    const newTrade: Trade = {
      ...trade,
      id,
      opportunityId: trade.opportunityId ?? null,
      blockNumber: trade.blockNumber ?? null,
      createdAt: new Date(),
    };
    this.trades.set(id, newTrade);
    return newTrade;
  }

  async updateTradeStatus(id: string, status: string, txHash?: string): Promise<void> {
    const trade = this.trades.get(id);
    if (trade) {
      trade.status = status;
      if (txHash) trade.txHash = txHash;
      this.trades.set(id, trade);
    }
  }

  // Engine Configuration
  async getEngineConfig(): Promise<EngineConfig | undefined> {
    return this.engineConfig;
  }

  async updateEngineConfig(updates: Partial<EngineConfig>): Promise<EngineConfig> {
    Object.assign(this.engineConfig, { ...updates, updatedAt: new Date() });
    return this.engineConfig;
  }
}

export const storage = new MemStorage();
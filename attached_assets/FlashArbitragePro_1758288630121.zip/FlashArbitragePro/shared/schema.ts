import { sql } from "drizzle-orm";
import { pgTable, text, varchar, decimal, integer, timestamp, boolean, jsonb } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// User schema for authentication
export const users = pgTable("users", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
});

// Arbitrage opportunities
export const arbitrageOpportunities = pgTable("arbitrage_opportunities", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  tokenA: text("token_a").notNull(),
  tokenB: text("token_b").notNull(),
  dexA: text("dex_a").notNull(),
  dexB: text("dex_b").notNull(),
  priceA: decimal("price_a", { precision: 18, scale: 8 }).notNull(),
  priceB: decimal("price_b", { precision: 18, scale: 8 }).notNull(),
  profitEth: decimal("profit_eth", { precision: 18, scale: 8 }).notNull(),
  profitUsd: decimal("profit_usd", { precision: 10, scale: 2 }).notNull(),
  gasEstimate: text("gas_estimate").notNull(),
  slippage: decimal("slippage", { precision: 5, scale: 2 }).notNull(),
  amount: decimal("amount", { precision: 18, scale: 8 }).notNull(),
  isExecuted: boolean("is_executed").default(false),
  createdAt: timestamp("created_at").defaultNow(),
  executedAt: timestamp("executed_at"),
});

// DEX protocols tracking
export const dexProtocols = pgTable("dex_protocols", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  name: text("name").notNull().unique(),
  isActive: boolean("is_active").default(true),
  pairCount: integer("pair_count").default(0),
  volume24h: decimal("volume_24h", { precision: 15, scale: 2 }).default("0"),
  latency: integer("latency").default(0),
  lastScan: timestamp("last_scan"),
  apiEndpoint: text("api_endpoint"),
  performance: decimal("performance", { precision: 5, scale: 2 }).default("0"),
});

// Trades execution history
export const trades = pgTable("trades", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  opportunityId: varchar("opportunity_id").references(() => arbitrageOpportunities.id),
  txHash: text("tx_hash").notNull().unique(),
  fromToken: text("from_token").notNull(),
  toToken: text("to_token").notNull(),
  amountIn: decimal("amount_in", { precision: 18, scale: 8 }).notNull(),
  amountOut: decimal("amount_out", { precision: 18, scale: 8 }).notNull(),
  profit: decimal("profit", { precision: 18, scale: 8 }).notNull(),
  gasUsed: text("gas_used").notNull(),
  gasCost: decimal("gas_cost", { precision: 18, scale: 8 }).notNull(),
  status: text("status").notNull(), // 'pending', 'success', 'failed'
  blockNumber: integer("block_number"),
  createdAt: timestamp("created_at").defaultNow(),
});

// Engine configuration
export const engineConfig = pgTable("engine_config", {
  id: varchar("id").primaryKey().default("main"),
  isRunning: boolean("is_running").default(false),
  scanInterval: integer("scan_interval").default(20), // seconds
  minProfitEth: decimal("min_profit_eth", { precision: 18, scale: 8 }).default("0.001"),
  maxSlippage: decimal("max_slippage", { precision: 5, scale: 2 }).default("0.5"),
  contractAddress: text("contract_address"),
  contractDeployed: boolean("contract_deployed").default(false),
  walletAddress: text("wallet_address"),
  settings: jsonb("settings").default({}),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Schemas
export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
});

export const insertArbitrageOpportunitySchema = createInsertSchema(arbitrageOpportunities).omit({
  id: true,
  createdAt: true,
});

export const insertDexProtocolSchema = createInsertSchema(dexProtocols).omit({
  id: true,
});

export const insertTradeSchema = createInsertSchema(trades).omit({
  id: true,
  createdAt: true,
});

export const insertEngineConfigSchema = createInsertSchema(engineConfig).omit({
  updatedAt: true,
});

// Types
export type User = typeof users.$inferSelect;
export type InsertUser = z.infer<typeof insertUserSchema>;

export type ArbitrageOpportunity = typeof arbitrageOpportunities.$inferSelect;
export type InsertArbitrageOpportunity = z.infer<typeof insertArbitrageOpportunitySchema>;

export type DexProtocol = typeof dexProtocols.$inferSelect;
export type InsertDexProtocol = z.infer<typeof insertDexProtocolSchema>;

export type Trade = typeof trades.$inferSelect;
export type InsertTrade = z.infer<typeof insertTradeSchema>;

export type EngineConfig = typeof engineConfig.$inferSelect;
export type InsertEngineConfig = z.infer<typeof insertEngineConfigSchema>;

// WebSocket message types
export const WSMessageSchema = z.object({
  type: z.enum(['arbitrage_opportunity', 'engine_status', 'dex_update', 'trade_executed', 'error']),
  payload: z.any(),
  timestamp: z.number(),
});

export type WSMessage = z.infer<typeof WSMessageSchema>;

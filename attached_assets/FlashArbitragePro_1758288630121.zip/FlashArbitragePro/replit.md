# ARBEngine - Arbitrage Trading Bot

## Overview

ARBEngine is a real-time cryptocurrency arbitrage trading bot built with modern web technologies. The application monitors multiple decentralized exchanges (DEXs) for price differences between trading pairs and executes profitable arbitrage trades automatically. It features a dashboard interface for monitoring opportunities, managing DEX protocols, and controlling the arbitrage engine.

The system combines real-time data scanning, smart contract interactions, and a responsive web interface to provide a complete arbitrage trading solution. The application tracks performance metrics, displays live opportunities, and manages trade execution through Ethereum smart contracts.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
- **Framework**: React with TypeScript for type safety and modern development
- **Styling**: Tailwind CSS with shadcn/ui component library for consistent, professional UI components
- **State Management**: TanStack React Query for server state management and caching
- **Routing**: Wouter for lightweight client-side routing
- **Real-time Updates**: WebSocket connection for live data streaming from the backend

### Backend Architecture
- **Runtime**: Node.js with Express.js server framework
- **Language**: TypeScript with ES modules for modern JavaScript features
- **API Structure**: RESTful endpoints with WebSocket support for real-time communication
- **Development Setup**: Vite for fast development builds and hot module replacement

### Data Storage Solutions
- **Primary Database**: PostgreSQL with Drizzle ORM for type-safe database operations
- **Database Provider**: Neon Database (serverless PostgreSQL)
- **Schema Management**: Drizzle Kit for migrations and schema management
- **Session Storage**: PostgreSQL-based session storage with connect-pg-simple
- **In-Memory Fallback**: Memory storage implementation for development and testing

### Core Services Architecture
- **Arbitrage Service**: Core engine for scanning opportunities and executing trades
- **DEX Service**: Integration layer for multiple decentralized exchanges (Uniswap V2/V3, SushiSwap, Curve)
- **Web3 Service**: Ethereum blockchain interaction using ethers.js
- **Contract Service**: Smart contract deployment and interaction management

### Authentication and Authorization
- Simple username/password authentication stored in PostgreSQL
- Session-based authentication with secure cookie management
- No complex role-based access control - designed for single-user or trusted environment usage

## External Dependencies

### Blockchain Infrastructure
- **Ethereum Network**: Mainnet interaction through Alchemy JSON-RPC provider
- **Web3 Library**: ethers.js v6 for blockchain interactions
- **Smart Contracts**: Custom arbitrage bot contracts for trade execution

### DEX Protocol APIs
- **1inch API**: Aggregated DEX data and price feeds
- **0x API**: Additional DEX protocol access
- **Etherscan API**: Ethereum network data and transaction verification
- **Multiple DEX Direct Integration**: Uniswap V2/V3, SushiSwap, Curve protocols

### Development and Deployment
- **Replit Integration**: Custom Vite plugins for Replit development environment
- **PostgreSQL Database**: Neon serverless database for production data storage
- **Session Management**: PostgreSQL-backed session store for user authentication

### UI Component Libraries
- **Radix UI**: Accessible component primitives for complex UI elements
- **Lucide Icons**: Consistent icon set for the interface
- **Tailwind CSS**: Utility-first CSS framework with custom design system
- **shadcn/ui**: Pre-built component library built on Radix and Tailwind

### Real-time Communication
- **WebSocket Server**: Custom WebSocket implementation for live updates
- **React Query**: Intelligent data fetching with caching and synchronization
- **Axios**: HTTP client for API requests with interceptor support

The architecture emphasizes real-time performance, type safety, and modularity. The system can handle high-frequency data updates while maintaining a responsive user interface. The modular service architecture allows for easy extension to additional DEX protocols and trading strategies.